/**
 * aqualogicascraper.js  (v2 - works with different product page layouts)
 *
 * Setup:  npm i cheerio xlsx
 * Run:    node aqualogicascraper.js --input products.json
 *         node aqualogicascraper.js --input products.json --limit 2
 *         node aqualogicascraper.js --input products.json --delay 2500
 *
 * If a page is missing description / ingredients / FAQs, its raw HTML is saved to
 *   "aqualogica - results/debug/{handle}.html"
 * so the selectors can be fixed.
 */
import fs from "node:fs";
import path from "node:path";
import * as cheerio from "cheerio";
import XLSX from "xlsx";

// ---------------------------------------------------------------- config
const BASE_URL = 'https://aqualogica.in';
const args = process.argv.slice(2);
const getArg = (name, def) => {
  const i = args.indexOf(`--${name}`);
  return i !== -1 && args[i + 1] ? args[i + 1] : def;
};

const INPUT_FILE = getArg('input', 'products.json');
const LIMIT = parseInt(getArg('limit', '0'), 10) || 0;
const DELAY_MS = parseInt(getArg('delay', '1500'), 10);
const OUTPUT_DIR = 'aqualogica - results';
const DEBUG_DIR = path.join(OUTPUT_DIR, 'debug');
fs.mkdirSync(DEBUG_DIR, { recursive: true });
const OUT_JSON = path.join(OUTPUT_DIR, 'SUN_DAMAGE.json');
const OUT_JSONL = path.join(OUTPUT_DIR, 'SUN_DAMAGE.jsonl');
const OUT_XLSX = path.join(OUTPUT_DIR, 'SUN_DAMAGE.xlsx');

const HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-IN,en;q=0.9',
};

// ---------------------------------------------------------------- helpers
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const clean = (s = '') =>
  String(s)
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\s*\n\s*/g, '\n')
    .trim();

const num = (s) => {
  const m = String(s ?? '').replace(/,/g, '').match(/\d+(\.\d+)?/);
  return m ? parseFloat(m[0]) : null;
};

// text of an element, keeping line breaks for <br>, <p>, <li>, <div>
function textOf($, el) {
  const $c = $(el).clone();
  $c.find('script,style').remove();
  $c.find('br').replaceWith('\n');
  $c.find('p,li,div,h1,h2,h3,h4,h5,h6,tr').each((_, n) => {
    $(n).append('\n');
  });
  return clean($c.text());
}

const listOf = ($, root, sel) =>
  $(root)
    .find(sel)
    .map((_, n) => clean($(n).text()))
    .get()
    .filter(Boolean);

const normQ = (q) => q.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

// ---------------------------------------------------------------- source json
function baseRecord(p) {
  const v0 = (p.variants || [])[0] || {};
  let bodyText = '';
  if (p.body_html) {
    const $b = cheerio.load(p.body_html, null, false);
    bodyText = textOf($b, $b.root());
  }
  return {
    id: p.id,
    handle: p.handle,
    title: p.title,
    url: `${BASE_URL}/products/${p.handle}`,
    vendor: p.vendor,
    product_type: p.product_type,
    tags: p.tags || [],
    sku: v0.sku || null,
    json_price: num(v0.price),
    json_compare_at_price: num(v0.compare_at_price),
    available: v0.available ?? null,
    grams: v0.grams ?? null,
    options: p.options || [],
    variants: (p.variants || []).map((v) => ({
      id: v.id,
      title: v.title,
      sku: v.sku,
      price: num(v.price),
      compare_at_price: num(v.compare_at_price),
      available: v.available,
      grams: v.grams,
    })),
    featured_image: (p.images || [])[0]?.src || null,
    image_urls: (p.images || []).map((i) => i.src),
    published_at: p.published_at,
    created_at: p.created_at,
    updated_at: p.updated_at,
    json_body_text: bodyText,
  };
}

// ---------------------------------------------------------------- page parsing
function parseJsonLd($) {
  const out = [];
  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      const j = JSON.parse($(el).html());
      Array.isArray(j) ? out.push(...j) : out.push(j);
    } catch (e) {
      /* ignore broken blocks */
    }
  });
  return out;
}

const summaryTitle = ($, d) => clean($(d).children('summary').first().text());

// FAQ block -> [{question, answer}]. Tries 3 layouts.
function parseFaqAccordion($, $content) {
  let out = [];

  // A) nested <details>: summary = question, rest = answer
  $content.find('details').each((_, d) => {
    const $d = $(d);
    const q = clean($d.children('summary').first().text());
    const $c = $d.clone();
    $c.children('summary').remove();
    const a = textOf($, $c);
    if (q && a) out.push({ question: q, answer: a });
  });
  if (out.length) return out;

  // B) <p><strong>Question?</strong><br>Answer</p>
  $content.find('p').each((_, p) => {
    const $p = $(p);
    const q = clean($p.find('strong, b').first().text());
    if (!q) return;
    const $c = $p.clone();
    $c.find('strong, b').first().remove();
    $c.find('br').replaceWith('\n');
    const a = clean($c.text());
    if (a) out.push({ question: q, answer: a });
  });
  if (out.length) return out;

  // C) plain lines: a line ending with "?" starts a new question
  let cur = null;
  textOf($, $content)
    .split('\n')
    .map(clean)
    .filter(Boolean)
    .forEach((line) => {
      if (line.endsWith('?')) {
        cur = { question: line, answer: '' };
        out.push(cur);
      } else if (cur) {
        cur.answer += (cur.answer ? '\n' : '') + line;
      }
    });
  return out.filter((f) => f.answer);
}

function extractPage(html) {
  const $ = cheerio.load(html);
  const data = {};
  const ld = parseJsonLd($);

  data.meta_description = clean($('meta[name="description"]').attr('content') || '');

  // ---- JSON-LD: product specs, certifications, rating
  const ldProduct = ld.find((x) => x['@type'] === 'Product');
  if (ldProduct) {
    data.ld_description = clean(ldProduct.description || '');
    data.specs = {};
    (ldProduct.additionalProperty || []).forEach((p) => {
      if (p.name) data.specs[p.name] = p.value;
    });
    data.certifications = (ldProduct.hasCertification || []).map((c) => ({
      name: c.name,
      issued_by: c.issuedBy?.name || null,
      id: c.certificationIdentification || null,
      url: c.url || null,
    }));
    if (ldProduct.aggregateRating) {
      data.rating = num(ldProduct.aggregateRating.ratingValue);
      data.review_count = num(ldProduct.aggregateRating.reviewCount);
    }
  }

  // ---- title / subtitle / price on the page
  const main = $('.hdt-main-product').first();
  data.page_title = clean(main.find('h1').first().text() || $('title').text());
  data.subtitle = clean(main.find('.htd-product__subtitle').first().text());
  data.page_price = num(main.find('hdt-price .hdt-money').first().text());
  data.page_mrp = num(main.find('hdt-compare-at-price .hdt-money').first().text());
  data.page_discount = clean(main.find('hdt-discount .hdt-money-discount').first().text());
  data.net_content = clean(main.find('hdt-net-content').first().text());

  data.highlights = listOf($, main, '.what-it-does-pill span');

  // ---- size variants
  data.size_variants = main
    .find('.product-variant-container .hdt-product-form_wrap-link-item')
    .map((_, el) => {
      const $el = $(el);
      const href = $el.find('a').attr('href') || '';
      return {
        name: clean($el.find('.hdt-linked-product-title').text()),
        url: href ? new URL(href, BASE_URL).href : null,
        price: num($el.find('.hdt-linked-product-price').first().text()),
        mrp: num($el.find('.hdt-linked-product-compare-price-amount').text()),
        discount: clean($el.find('.hdt-linked-product-save-off').text()),
        unit_price: clean($el.find('.net-content').text()),
        selected: $el.hasClass('is-selected'),
      };
    })
    .get();

  // ---- offers
  data.offers = main
    .find('.available-offers .offer-card')
    .map((_, el) => ({
      title: clean($(el).find('.offer-title').text()),
      code: clean($(el).find('.offer-code').text()),
    }))
    .get();

  // ---- ACCORDIONS: every <details> with a <summary>, matched by heading text
  data.other_sections = {};
  data.detected_sections = [];
  let faqFromAccordion = [];

  $('details').each((_, el) => {
    const $el = $(el);
    if (!$el.children('summary').length) return;
    if ($el.hasClass('pdp-faq-item')) return; // handled below

    const title = summaryTitle($, el);
    if (!title) return;
    const t = title.toLowerCase();
    const isFaq = /\bfaq/.test(t);

    // skip questions nested inside a FAQs accordion
    const insideFaq = $el
      .parents('details')
      .filter((_, p) => /\bfaq/.test(summaryTitle($, p).toLowerCase())).length;
    if (insideFaq) return;

    // skip big wrapper accordions that only contain other accordions
    if (!isFaq && $el.find('details').length) return;

    const $content = $el.clone();
    $content.children('summary').remove();
    if (!clean($content.text())) return;

    data.detected_sections.push(title);

    if (isFaq) {
      faqFromAccordion = faqFromAccordion.concat(parseFaqAccordion($, $content));
    } else if (t.includes('description')) {
      data.description = textOf($, $content);
      data.description_html = ($content.html() || '').trim();
    } else if (t.includes('ingredient')) {
      data.ingredients = textOf($, $content);
      data.ingredients_list = data.ingredients
        .replace(/\.$/, '')
        .split(/,\s+(?![^()]*\))/) // split on commas that are NOT inside ( )
        .map((s) => s.trim())
        .filter(Boolean);
    } else if (t.includes('how to use')) {
      data.how_to_use = listOf($, $content, 'li');
      if (!data.how_to_use.length) {
        data.how_to_use = textOf($, $content).split('\n').filter(Boolean);
      }
    } else if (/who is it|who can use|good for|best for/.test(t)) {
      const who = {};
      $content.find('.who-can-use-heading').each((_, h) => {
        who[clean($(h).text())] = listOf($, $(h).next('ul'), 'li');
      });
      if (!Object.keys(who).length) {
        who[title] = textOf($, $content).split('\n').filter(Boolean);
      }
      data.who_is_it_best_for = who;
    } else if (t.includes('experience')) {
      const exp = {};
      $content.find('.hydrate-sub-heading').each((_, h) => {
        exp[clean($(h).text())] = clean($(h).next('.hydrate-text').text());
      });
      data.experience = exp;
      data.experience_text = textOf($, $content);
    } else {
      data.other_sections[title] = textOf($, $content);
    }
  });

  // description fallbacks
  if (!data.description) {
    data.description = data.ld_description || data.meta_description || '';
    data.description_source = data.ld_description ? 'json_ld' : 'meta';
  }

  // ---- tabs: key ingredients, benefits & results, dermat notes (only on some products)
  data.key_ingredients = $('.new-product-tabs__ingredient-grid .new-product-tabs__card')
    .map((_, el) => ({
      group: clean($(el).find('.new-product-tabs__card-title').text()),
      items: listOf($, el, '.new-product-tabs__item-label'),
    }))
    .get();

  data.benefits_and_results = $('.new-product-tabs__results-column')
    .map((_, el) => ({
      period: clean($(el).find('.new-product-tabs__results-heading').text()),
      items: listOf($, el, '.new-product-tabs__item-text'),
    }))
    .get();
  data.results_disclaimer = clean($('.new-product-tabs__results-disclaimer').first().text());

  data.dermat_notes = $('.new-product-tabs__item-list--dermat .new-product-tabs__item')
    .map((_, el) => ({
      label: clean($(el).find('.new-product-tabs__item-label').text()),
      sublabel: clean($(el).find('.new-product-tabs__item-sublabel').text()),
    }))
    .get();

  data.claims = $('.claims-certifications__card:not(.is-clone)')
    .map((_, el) => ({
      title: clean($(el).find('.claims-certifications__card-title').text()),
      description: clean($(el).find('.claims-certifications__card-desc').text()),
      report_url: $(el).find('a.claims-certifications__card-link').attr('href') || null,
    }))
    .get();

  // ---- FAQs: merged + de-duplicated
  const faqs = [];
  const seen = new Set();
  const addFaq = (q, a, source) => {
    q = clean(q);
    a = clean(a);
    if (!q || !a) return;
    const k = normQ(q);
    if (seen.has(k)) return;
    seen.add(k);
    faqs.push({ question: q, answer: a, source });
  };

  const ldFaq = ld.find((x) => x['@type'] === 'FAQPage');
  (ldFaq?.mainEntity || []).forEach((e) =>
    addFaq(e.name, e.acceptedAnswer?.text, 'json_ld')
  );

  $('details.pdp-faq-item').each((_, el) => {
    const $c = $(el).clone();
    $c.children('summary').remove();
    addFaq(summaryTitle($, el), textOf($, $c), 'faq_section');
  });

  faqFromAccordion.forEach((f) => addFaq(f.question, f.answer, 'more_info'));

  data.faqs = faqs;
  return data;
}

// ---------------------------------------------------------------- network
async function fetchHtml(url, tries = 3) {
  let lastErr;
  for (let i = 1; i <= tries; i++) {
    try {
      const res = await fetch(url, {
        headers: HEADERS,
        signal: AbortSignal.timeout(30000),
        redirect: 'follow',
      });
      if (res.status === 404) throw Object.assign(new Error('HTTP 404'), { noRetry: true });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.text();
    } catch (e) {
      lastErr = e;
      if (e.noRetry) break;
      await sleep(2000 * i);
    }
  }
  throw lastErr;
}

// ---------------------------------------------------------------- output
function loadDone() {
  const done = new Map();
  if (!fs.existsSync(OUT_JSONL)) return done;
  fs.readFileSync(OUT_JSONL, 'utf8')
    .split('\n')
    .filter(Boolean)
    .forEach((line) => {
      try {
        const r = JSON.parse(line);
        // only treat as done if it really has the content we want
        if (r.scrape_status === 'ok' && r.ingredients && r.faqs?.length) {
          done.set(r.handle, r);
        }
      } catch (e) {
        /* skip bad line */
      }
    });
  return done;
}

const cut = (s) => (typeof s === 'string' && s.length > 32000 ? s.slice(0, 32000) : s);

function toRow(r) {
  const faqText = (r.faqs || [])
    .map((f) => `Q: ${f.question}\nA: ${f.answer}`)
    .join('\n\n');
  const who = Object.entries(r.who_is_it_best_for || {})
    .map(([k, v]) => `${k}: ${v.join(', ')}`)
    .join('\n');
  return {
    id: r.id,
    handle: r.handle,
    title: r.title,
    url: r.url,
    product_type: r.product_type,
    vendor: r.vendor,
    tags: (r.tags || []).join(', '),
    sku: r.sku,
    json_price: r.json_price,
    page_price: r.page_price,
    page_mrp: r.page_mrp,
    page_discount: r.page_discount,
    net_content: r.net_content,
    rating: r.rating,
    review_count: r.review_count,
    subtitle: r.subtitle,
    highlights: (r.highlights || []).join(', '),
    featured_image: r.featured_image,
    image_urls: (r.image_urls || []).join('\n'),
    description: cut(r.description),
    ingredients: cut(r.ingredients),
    how_to_use: (r.how_to_use || []).join('\n'),
    who_is_it_best_for: who,
    faqs_count: (r.faqs || []).length,
    faqs: cut(faqText),
    size_variants: (r.size_variants || [])
      .map((v) => `${v.name} - Rs.${v.price}`)
      .join('\n'),
    scrape_status: r.scrape_status,
    scrape_error: r.scrape_error || '',
  };
}

function saveAll(records) {
  fs.writeFileSync(OUT_JSON, JSON.stringify(records, null, 2), 'utf8');
  try {
    const ws = XLSX.utils.json_to_sheet(records.map(toRow));
    ws['!cols'] = Object.keys(toRow({})).map((k) => ({
      wch: ['description', 'faqs', 'ingredients', 'image_urls'].includes(k) ? 60 : 20,
    }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'products');
    XLSX.writeFile(wb, OUT_XLSX);
  } catch (e) {
    console.log(`  (could not write Excel - is it open? ${e.message})`);
  }
}

// ---------------------------------------------------------------- main
(async () => {
  if (!fs.existsSync(INPUT_FILE)) {
    console.error(`Input file not found: ${INPUT_FILE}`);
    process.exit(1);
  }
  const raw = JSON.parse(fs.readFileSync(INPUT_FILE, 'utf8'));
  let products = Array.isArray(raw) ? raw : raw.products || [];
  if (LIMIT) products = products.slice(0, LIMIT);

  const done = loadDone();
  const results = [];
  console.log(`Products: ${products.length}  |  already done: ${done.size}`);

  // the old JSONL has the empty results from the first run -> start fresh for entries not "done"
  if (fs.existsSync(OUT_JSONL)) fs.writeFileSync(OUT_JSONL, '', 'utf8');
  done.forEach((r) => fs.appendFileSync(OUT_JSONL, JSON.stringify(r) + '\n', 'utf8'));

  for (let i = 0; i < products.length; i++) {
    const p = products[i];
    const tag = `[${i + 1}/${products.length}] ${p.handle.slice(0, 60)}`;

    if (done.has(p.handle)) {
      results.push(done.get(p.handle));
      console.log(`${tag} - skipped (already scraped)`);
      continue;
    }

    const record = baseRecord(p);
    try {
      const html = await fetchHtml(record.url);
      Object.assign(record, extractPage(html));
      record.scrape_status = 'ok';

      const missing = [];
      if (record.description_source) missing.push('description');
      if (!record.ingredients) missing.push('ingredients');
      if (!record.faqs.length) missing.push('faqs');

      console.log(
        `${tag} - ok | price ${record.page_price} | faqs ${record.faqs.length} | ` +
          `desc ${record.description_source ? 'fallback' : 'yes'} | ingredients ${record.ingredients ? 'yes' : 'NO'}`
      );
      console.log(`    sections found: ${record.detected_sections.join(' | ') || '(none)'}`);

      if (missing.length) {
        const f = path.join(DEBUG_DIR, `${p.handle.slice(0, 80)}.html`);
        fs.writeFileSync(f, html, 'utf8');
        console.log(`    missing: ${missing.join(', ')} -> saved HTML to ${f}`);
      }
    } catch (e) {
      record.scrape_status = 'failed';
      record.scrape_error = e.message;
      console.log(`${tag} - FAILED: ${e.message}`);
    }
    record.scraped_at = new Date().toISOString();

    results.push(record);
    fs.appendFileSync(OUT_JSONL, JSON.stringify(record) + '\n', 'utf8');
    if ((i + 1) % 10 === 0) saveAll(results);

    await sleep(DELAY_MS + Math.floor(Math.random() * 700));
  }

  saveAll(results);
  const ok = results.filter((r) => r.scrape_status === 'ok').length;
  console.log(`\nDone. ok: ${ok}, failed: ${results.length - ok}`);
  console.log(`Files: ${OUT_JSON}, ${OUT_JSONL}, ${OUT_XLSX}`);
})();