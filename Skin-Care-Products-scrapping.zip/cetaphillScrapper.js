import fs from "node:fs";
import path from "node:path";
import ExcelJS from "exceljs";
import { chromium } from "playwright";

const INPUT_FILE = process.argv.find((arg, index, all) => all[index - 1] === "--input") || "ceta-phill.json";
const LIMIT_ARG = process.argv.find((arg, index, all) => all[index - 1] === "--limit");
const LIMIT = LIMIT_ARG ? Math.max(0, Number.parseInt(LIMIT_ARG, 10) || 0) : 0;
const OUTPUT_DIR = "cetaphill result";
const JSON_FILE = path.join(OUTPUT_DIR, "products.json");
const JSONL_FILE = path.join(OUTPUT_DIR, "products.jsonl");
const XLSX_FILE = path.join(OUTPUT_DIR, "products.xlsx");
const NAVIGATION_TIMEOUT_MS = 60000;
const PAUSE_AFTER_LOAD_MS = 1200;

fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const clean = value => String(value ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function parseInput(rawText) {
  let data;
  try {
    data = JSON.parse(rawText);
  } catch (error) {
    // ceta-phill.json currently starts with ListItem objects but is missing
    // its opening {"itemListElement":[ wrapper.
    try {
      data = JSON.parse(`{"itemListElement":[${rawText.trim()}`);
    } catch {
      throw new Error(`Could not parse input JSON: ${error.message}`);
    }
  }

  if (Array.isArray(data)) return data;
  if (Array.isArray(data.itemListElement)) {
    return data.itemListElement.map(entry => entry.item || entry);
  }
  if (Array.isArray(data.products)) return data.products;
  throw new Error("Input JSON must contain product URLs or an itemListElement array.");
}

function loadCompleted() {
  const completed = new Map();
  if (!fs.existsSync(JSONL_FILE)) return completed;
  for (const line of fs.readFileSync(JSONL_FILE, "utf8").split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const row = JSON.parse(line);
      if (row.url) completed.set(row.url, row);
    } catch {
      // Ignore an incomplete final line from an interrupted run.
    }
  }
  return completed;
}

async function firstText(page, selectors) {
  for (const selector of selectors) {
    const locator = page.locator(selector).first();
    try {
      const text = clean(await locator.innerText({ timeout: 1500 }));
      if (text) return text;
    } catch {}
  }
  return "";
}

async function firstAttribute(page, selectors, attribute) {
  for (const selector of selectors) {
    try {
      const value = clean(await page.locator(selector).first().getAttribute(attribute, { timeout: 1500 }));
      if (value) return value;
    } catch {}
  }
  return "";
}

async function listText(page, selectors) {
  const values = [];
  for (const selector of selectors) {
    try {
      const found = await page.locator(selector).allInnerTexts();
      for (const value of found.map(clean).filter(Boolean)) {
        if (!values.includes(value)) values.push(value);
      }
    } catch {}
  }
  return values;
}

async function structuredProduct(page) {
  const scripts = await page.locator('script[type="application/ld+json"]').allTextContents().catch(() => []);
  const queue = [];
  for (const script of scripts) {
    try {
      queue.push(JSON.parse(script));
    } catch {}
  }

  while (queue.length) {
    const value = queue.shift();
    if (!value) continue;
    if (Array.isArray(value)) {
      queue.push(...value);
      continue;
    }
    if (typeof value !== "object") continue;
    const types = Array.isArray(value["@type"]) ? value["@type"] : [value["@type"]];
    if (types.includes("Product")) return value;
    if (value["@graph"]) queue.push(value["@graph"]);
    if (value.mainEntity) queue.push(value.mainEntity);
    if (value.itemListElement) queue.push(value.itemListElement);
  }
  return null;
}

async function scrapeProduct(page, source) {
  const url = clean(source.url || source.item?.url);
  if (!url) throw new Error("Input record has no URL.");

  await page.goto(url, { waitUntil: "domcontentloaded", timeout: NAVIGATION_TIMEOUT_MS });
  await page.waitForTimeout(PAUSE_AFTER_LOAD_MS);

  const schema = await structuredProduct(page);
  const name = await firstText(page, [
    "h1.product-name",
    ".pdp-main h1.product-name",
    "h1[class*='product-name']",
    "main h1",
    "h1"
  ]) || clean(schema?.name) || clean(source.name || source.title);

  const description = await firstText(page, [
    "#longDescription .description-text",
    ".product-long-description .description-text",
    ".pdp-main .short-desc",
    ".product-description",
    ".description-text"
  ]) || clean(schema?.description) ||
    await firstAttribute(page, ["meta[property='og:description']", "meta[name='description']"], "content");

  const ingredients = await firstText(page, [
    "#productIngredients .content-asset p",
    "#productIngredients .content-asset",
    "#productIngredients",
    "[id*='productIngredients'] .content-asset",
    ".product-ingredients"
  ]);

  const features = await listText(page, [
    ".pdp-main .short-desc li",
    ".short-desc li",
    ".product-features li",
    ".features li",
    "[id*='Features'] li",
    "[id*='features'] li"
  ]);

  let price = await firstText(page, [
    ".pdp-main .price .sales .value",
    ".pdp-main .price-sales",
    ".pdp-main .product-price",
    ".product-detail .price .value",
    "[itemprop='price']"
  ]);
  if (!price) {
    price = await firstAttribute(page, ["meta[property='product:price:amount']", "meta[itemprop='price']"], "content");
  }
  if (!price && schema?.offers) {
    const offer = Array.isArray(schema.offers) ? schema.offers[0] : schema.offers;
    if (offer?.price != null) price = String(offer.price);
  }

  return {
    id: source.id ?? null,
    name,
    url,
    price,
    description,
    ingredients,
    features,
    scrape_status: "ok",
    scrape_error: "",
    scraped_at: new Date().toISOString()
  };
}

function saveJsonAndJsonl(records) {
  fs.writeFileSync(JSON_FILE, JSON.stringify(records, null, 2), "utf8");
}

async function saveExcel(records) {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Cetaphil Products");
  sheet.columns = [
    { header: "ID", key: "id", width: 18 },
    { header: "Product Name", key: "name", width: 42 },
    { header: "URL", key: "url", width: 60 },
    { header: "Price", key: "price", width: 18 },
    { header: "Description", key: "description", width: 70 },
    { header: "Ingredients", key: "ingredients", width: 70 },
    { header: "Features", key: "features", width: 55 },
    { header: "Status", key: "scrape_status", width: 15 },
    { header: "Error", key: "scrape_error", width: 40 }
  ];
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  for (const row of records) {
    sheet.addRow({ ...row, features: (row.features || []).join("\n") })
      .alignment = { vertical: "top", wrapText: true };
  }
  await workbook.xlsx.writeFile(XLSX_FILE);
}

async function main() {
  if (!fs.existsSync(INPUT_FILE)) throw new Error(`Input file not found: ${INPUT_FILE}`);
  const sourceProducts = parseInput(fs.readFileSync(INPUT_FILE, "utf8"));
  const products = LIMIT ? sourceProducts.slice(0, LIMIT) : sourceProducts;
  const completed = loadCompleted();
  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  page.setDefaultTimeout(10000);

  console.log(`Products to process: ${products.length}`);
  try {
    for (let i = 0; i < products.length; i++) {
      const source = products[i];
      const url = clean(source.url || source.item?.url);
      if (completed.get(url)?.scrape_status === "ok") {
        console.log(`[${i + 1}/${products.length}] Already saved: ${url}`);
        continue;
      }

      console.log(`[${i + 1}/${products.length}] ${url || "Missing URL"}`);
      let row;
      try {
        row = await scrapeProduct(page, source);
        console.log(`  ${row.name || "Name missing"} | ${row.price || "Price missing"}`);
      } catch (error) {
        row = {
          id: source.id ?? null,
          name: clean(source.name || source.title),
          url,
          price: "",
          description: "",
          ingredients: "",
          features: [],
          scrape_status: "failed",
          scrape_error: error.message,
          scraped_at: new Date().toISOString()
        };
        console.error(`  Failed: ${error.message}`);
      }

      completed.set(url || `missing-${i}`, row);
      fs.appendFileSync(JSONL_FILE, JSON.stringify(row) + "\n", "utf8");
      const current = products.map((p, index) => completed.get(clean(p.url || p.item?.url)) || null).filter(Boolean);
      saveJsonAndJsonl(current);
      await sleep(500);
    }
  } finally {
    await browser.close();
  }

  const records = products.map((p, index) => completed.get(clean(p.url || p.item?.url)) || {
    id: p.id ?? null,
    name: clean(p.name || p.title),
    url: clean(p.url || p.item?.url),
    price: "",
    description: "",
    ingredients: "",
    features: [],
    scrape_status: "not_scraped",
    scrape_error: "No saved result for this URL"
  });
  saveJsonAndJsonl(records);
  await saveExcel(records);
  console.log(`Saved JSON, JSONL, and Excel in: ${OUTPUT_DIR}`);
}

main().catch(error => {
  console.error(`Fatal error: ${error.message}`);
  process.exitCode = 1;
});
