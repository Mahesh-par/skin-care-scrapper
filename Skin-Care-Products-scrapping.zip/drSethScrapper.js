import fs from "node:fs";
import path from "node:path";
import * as cheerio from "cheerio";
import ExcelJS from "exceljs";

const BASE_URL = "https://drsheths.com/products/";
const INPUT_FILE = process.argv.slice(2).find(arg => !arg.startsWith("--")) ||
  "dr-Smith-extracted-products.json";
const OUTPUT_DIR = "dr-Smith-Output";
const DEFAULT_PRODUCT_LIMIT = 3;
const PRODUCT_LIMIT = process.argv.includes("--all")
  ? Infinity
  : DEFAULT_PRODUCT_LIMIT;
const REQUEST_DELAY_MS = 1200;
const MAX_RETRIES = 3;

fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const clean = value => String(value ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();

function parseProducts(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data.products)) return data.products;
  throw new Error('Input JSON must be an array or contain a "products" array.');
}

function jsonLdObjects($) {
  const objects = [];
  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      const visit = node => {
        if (!node) return;
        if (Array.isArray(node)) return node.forEach(visit);
        if (typeof node !== "object") return;
        objects.push(node);
        if (node["@graph"]) visit(node["@graph"]);
        if (node.mainEntity) visit(node.mainEntity);
      };
      visit(JSON.parse($(el).contents().text()));
    } catch {}
  });
  return objects;
}

function getProductJson($) {
  const payload = $("#flits-product-data").first().text();
  if (payload) {
    try {
      const product = JSON.parse(payload);
      if (product?.handle || product?.title) return product;
    } catch {}
  }
  return {};
}

function readAccordionContent($item, $) {
  return $item.find(
    ".hdt-product-accordion__content, .product-faqs-content, .accordion-content"
  ).first();
}

function extractFaq(content, $) {
  const faqs = [];
  content.find(
    ".product-faqs-item, .product-faq-item, .faq-item, .drag-faq-item, li"
  ).each((_, el) => {
    const item = $(el);
    const question = clean(item.find(
      "strong, .question, .faq-question, summary, h3, h4"
    ).first().text());
    const answer = clean(item.find(
      ".product-faqs-answer, .faq-answer, .answer, p, .detail1"
    ).text());
    if (question && answer && question !== answer) {
      faqs.push({ question: question.replace(/[?:\s]+$/, "?"), answer });
    }
  });

  const seen = new Set();
  return faqs.filter(faq => {
    const key = `${faq.question.toLowerCase()}|${faq.answer.toLowerCase()}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function extractDetailCards(content, $) {
  return content.find(".product-detail-card-inner").map((_, el) => {
    const card = $(el);
    const name = clean(card.find(
      ".product-detail-card-title, .detail-title, h3, h4, strong"
    ).first().text()).replace(/\s*:\s*$/, "");
    const detail = clean(card.find(
      ".detail1, .product-detail-card-description, p"
    ).text());
    if (!name && !detail) return null;
    return { name, benefit: detail };
  }).get().filter(Boolean);
}

function extractPage(html, inputProduct, url) {
  const $ = cheerio.load(html);
  const productJson = getProductJson($);
  const structured = jsonLdObjects($);
  const sections = {
    "Product description": "",
    "Key Ingredients": "",
    "How it works": "",
    "Ingredients": "",
    "Key Benefits": "",
    "FAQ": []
  };

  $(".hdt-product-accordion__item, .hdt-product-accordion-item").each((_, el) => {
    const item = $(el);
    const title = clean(item.find(
      "summary .hdt-product-accordion__text, summary, .accordion-title"
    ).first().text()).replace(/[:：]\s*$/, "").toLowerCase();
    const content = readAccordionContent(item, $);
    if (!title || !content.length) return;

    if (["description", "product description"].includes(title)) {
      sections["Product description"] = clean(content.text());
    } else if (["key ingredients", "key ingredient"].includes(title)) {
      sections["Key Ingredients"] = extractDetailCards(content, $);
      if (!sections["Key Ingredients"].length) {
        sections["Key Ingredients"] = clean(content.text());
      }
    } else if (["how it works", "how it work"].includes(title)) {
      sections["How it works"] = extractDetailCards(content, $);
      if (!sections["How it works"].length) {
        sections["How it works"] = clean(content.text());
      }
    } else if (["ingredients", "ingredient list"].includes(title)) {
      sections.Ingredients = clean(content.find(
        ".product-detail-card-description, .detail1"
      ).text()) || clean(content.text());
    } else if (["key benefits", "benefits"].includes(title)) {
      sections["Key Benefits"] = content.find("li").map((_, li) =>
        clean($(li).text())
      ).get().filter(Boolean);
      if (!sections["Key Benefits"].length) {
        sections["Key Benefits"] = extractDetailCards(content, $);
      }
      if (!sections["Key Benefits"].length) {
        sections["Key Benefits"] = clean(content.text());
      }
    } else if (["faq", "faqs", "frequently asked questions"].includes(title)) {
      sections.FAQ = extractFaq(content, $);
    }
  });

  // The pasted source places the FAQ list in a separate drag-faq-section,
  // outside the hdt product accordions. Read that static HTML directly.
  if (!sections.FAQ.length) {
    sections.FAQ = extractFaq(
      $(".drag-faq-section .drag-faq-accordion, .drag-faq-section"),
      $
    );
  }

  // Fallback to the page's structured Product description if an accordion
  // section is absent from the initial HTML response.
  const productSchema = structured.find(node => {
    const type = node["@type"];
    return type === "Product" || (Array.isArray(type) && type.includes("Product"));
  });
  const title = clean(productJson.title) ||
    clean(productSchema?.name) ||
    clean($("h1.hdt-product__title, h1").first().text()) ||
    inputProduct.title || "";
  const salePrice = clean($(".hdt-price__sale hdt-price .hdt-money, .hdt-price__sale .hdt-money")
    .first().text());
  const mrp = clean($(".hdt-price__sale hdt-compare-at-price .hdt-money, .hdt-compare-at-price .hdt-money")
    .first().text());
  const discount = clean($(".hdt-price__sale .discount-percentage, .discount-percentage")
    .first().text());
  const offer = Array.isArray(productSchema?.offers)
    ? productSchema.offers[0]
    : productSchema?.offers;
  const structuredPrice = offer?.price ?? offer?.lowPrice;
  const price = {
    sale_price: salePrice || (structuredPrice != null ? String.fromCodePoint(0x20B9) + structuredPrice : ""),
    mrp,
    discount
  };

  if (!sections["Product description"]) {
    sections["Product description"] = clean(
      productJson.description || productSchema?.description ||
      $("meta[property='og:description']").attr("content") || ""
    );
  }

  return {
    id: productJson.id ?? inputProduct.id ?? null,
    title: title || inputProduct.title || "",
    handle: inputProduct.handle || "",
    url,
    product_type: productJson.type || inputProduct.product_type || "",
    tags: inputProduct.tags || [],
    imageurl: inputProduct.imageurl || [],
    page_title: clean($("title").text()),
    price,
    "Key Ingredients": sections["Key Ingredients"],
    "Description": sections["Product description"],
    "How it works": sections["How it works"],
    "Ingredients": sections.Ingredients,
    "Key Benefits": sections["Key Benefits"],
    "FAQ": sections.FAQ,
    status: "ok",
    warnings: [
      ...(!sections["Product description"] ? ["Description section not found"] : []),
      ...(!sections["Key Ingredients"]?.length ? ["Key Ingredients section not found"] : []),
      ...(!sections["How it works"]?.length ? ["How it works section not found"] : []),
      ...(!sections.Ingredients ? ["Ingredients section not found"] : []),
      ...(!sections["Key Benefits"]?.length ? ["Key Benefits section not found"] : []),
      ...(!sections.FAQ.length ? ["FAQ section not found"] : []),
      ...(!price.sale_price ? ["Price not found"] : [])
    ],
    scraped_at: new Date().toISOString()
  };
}

async function fetchPage(url) {
  let lastError;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await fetch(url, {
        redirect: "follow",
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "en-IN,en;q=0.9"
        },
        signal: AbortSignal.timeout(30000)
      });
      if (!response.ok) throw new Error(`HTTP ${response.status} ${response.statusText}`);
      return { html: await response.text(), finalUrl: response.url };
    } catch (error) {
      lastError = error;
      if (attempt < MAX_RETRIES) await sleep(attempt * 1500);
    }
  }
  throw lastError;
}

async function main() {
  if (!fs.existsSync(INPUT_FILE)) throw new Error(`Input file not found: ${INPUT_FILE}`);
  const products = parseProducts(JSON.parse(fs.readFileSync(INPUT_FILE, "utf8")));
  const selectedProducts = products.slice(0, PRODUCT_LIMIT);
  const results = [];

  console.log(`Input products: ${products.length}; scraping: ${selectedProducts.length}`);

  for (let i = 0; i < selectedProducts.length; i++) {
    const product = selectedProducts[i];
    const handle = clean(product.handle);
    if (!handle) {
      results.push({ id: product.id ?? null, title: product.title || "", handle: "", tags: product.tags || [], imageurl: product.imageurl || [], status: "skipped", error: "No handle in input" });
      continue;
    }

    const url = new URL(encodeURIComponent(handle), BASE_URL).href;
    console.log(`[${i + 1}/${selectedProducts.length}] Fetching ${url}`);
    try {
      const { html, finalUrl } = await fetchPage(url);
      const result = extractPage(html, product, finalUrl);
      results.push(result);
      console.log(`  ${result.title || handle} | ${result.price.sale_price || "price missing"}`);
    } catch (error) {
      results.push({
        id: product.id ?? null,
        title: product.title || "",
        handle,
        url,
        tags: product.tags || [],
        imageurl: product.imageurl || [],
        status: "failed",
        error: error.message,
        scraped_at: new Date().toISOString()
      });
      console.error(`  Failed: ${error.message}`);
    }

    if (i < selectedProducts.length - 1) await sleep(REQUEST_DELAY_MS);
  }

  const jsonPath = path.join(OUTPUT_DIR, "products.json");
  const jsonlPath = path.join(OUTPUT_DIR, "products.jsonl");
  const excelPath = path.join(OUTPUT_DIR, "products.xlsx");
  fs.writeFileSync(jsonPath, JSON.stringify(results, null, 2), "utf8");
  fs.writeFileSync(jsonlPath, results.map(row => JSON.stringify(row)).join("\n") + "\n", "utf8");

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Products");
  sheet.columns = [
    { header: "Product Name", key: "title", width: 40 },
    { header: "Product ID", key: "id", width: 18 },
    { header: "Handle", key: "handle", width: 38 },
    { header: "URL", key: "url", width: 50 },
    { header: "Tags", key: "tags", width: 35 },
    { header: "Image URLs", key: "imageurl", width: 60 },
    { header: "Price", key: "price", width: 22 },
    { header: "Key Ingredients", key: "key_ingredients", width: 50 },
    { header: "Description", key: "description", width: 60 },
    { header: "How it works", key: "how_it_works", width: 55 },
    { header: "Ingredients", key: "ingredients", width: 60 },
    { header: "Key Benefits", key: "key_benefits", width: 55 },
    { header: "FAQ", key: "faq", width: 65 },
    { header: "Status", key: "status", width: 15 },
    { header: "Warnings", key: "warnings", width: 45 }
  ];
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  for (const row of results) {
    sheet.addRow({
      title: row.title || "",
      id: row.id ?? "",
      handle: row.handle || "",
      url: row.url || "",
      tags: (row.tags || []).join(", "),
      imageurl: (row.imageurl || []).join("\n"),
      price: row.price?.sale_price || "",
      key_ingredients: JSON.stringify(row["Key Ingredients"] || ""),
      description: row.Description || "",
      how_it_works: JSON.stringify(row["How it works"] || ""),
      ingredients: row.Ingredients || "",
      key_benefits: JSON.stringify(row["Key Benefits"] || ""),
      faq: JSON.stringify(row.FAQ || []),
      status: row.status || "",
      warnings: JSON.stringify(row.warnings || [])
    }).alignment = { vertical: "top", wrapText: true };
  }
  await workbook.xlsx.writeFile(excelPath);

  console.log(`Done. JSON, JSONL, and Excel saved in ${OUTPUT_DIR}`);
}

main().catch(error => {
  console.error("Fatal error:", error.message);
  process.exitCode = 1;
});
