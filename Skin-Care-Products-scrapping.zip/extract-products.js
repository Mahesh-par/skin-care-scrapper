
// const fs = require("node:fs");
// const path = require("node:path");
import fs from "node:fs";
import path from "node:path";
// Usage: node extract-products.js input.json
const INPUT_FILE = process.argv[2] || "products.json";
const OUTPUT_FILE = "dr-Smith-extracted-products.json";

try {
    // Read the original JSON file
    const rawData = fs.readFileSync(INPUT_FILE, "utf8");
    const data = JSON.parse(rawData);

    // Support JSON containing { products: [...] }
    // or a direct array of products
    const products = Array.isArray(data)
        ? data
        : data.products;

    if (!Array.isArray(products)) {
        throw new Error(
            'Invalid JSON format: expected a "products" array.'
        );
    }

    // Extract only the required fields
    const extractedProducts = products.map((product) => ({
        id: product.id ?? null,
        title: product.title ?? null,
        handle: product.handle ?? null,
        tags: Array.isArray(product.tags) ? product.tags : [],
        imageurl: Array.isArray(product.images)
            ? product.images
                .map((image) => image.src)
                .filter((url) => typeof url === "string" && url.length > 0)
            : []
    }));

    // Save extracted data
    fs.writeFileSync(
        OUTPUT_FILE,
        JSON.stringify(extractedProducts, null, 2),
        "utf8"
    );

    console.log(`Successfully extracted ${extractedProducts.length} products.`);
    console.log(`Output saved to: ${path.resolve(OUTPUT_FILE)}`);

} catch (error) {
    console.error("Error:", error.message);
    process.exitCode = 1;
}
