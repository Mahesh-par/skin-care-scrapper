import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ExcelJS from "exceljs";
import { chromium } from "playwright";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUTPUT_DIR = path.join(__dirname, "forest essentials result");
const LIMIT_INDEX = process.argv.indexOf("--limit");
const LIMIT = LIMIT_INDEX >= 0 ? Number(process.argv[LIMIT_INDEX + 1]) : Infinity;
const INPUT_INDEX = process.argv.indexOf("--input");
const DEFAULT_INPUT = path.join(OUTPUT_DIR, "forest-essentials-urls.json");
const INPUT_FILE = path.resolve(__dirname, INPUT_INDEX >= 0 ? process.argv[INPUT_INDEX + 1] : DEFAULT_INPUT);
const WAIT_AFTER_ACTION_MS = 500;

const clean = value => String(value ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
const unique = values => [...new Set(values.map(clean).filter(Boolean))];

function readProductUrls() {
  if (!fs.existsSync(INPUT_FILE)) throw new Error(`Product URL file not found: ${INPUT_FILE}`);
  const parsed = JSON.parse(fs.readFileSync(INPUT_FILE, "utf8"));
  const items = Array.isArray(parsed) ? parsed : parsed.products || parsed.urls;
  if (!Array.isArray(items)) throw new Error("URL input must be an array or contain a products/urls array.");
  const products = items.map(item => {
    if (typeof item === "string") return { url: item };
    return {
      ...item,
      url: item?.url || item?.product_url || item?.productUrl || "",
      title: item?.title || item?.name || "",
      listing_image_url: item?.listing_image_url || item?.image_url || item?.imageURL || item?.image || "",
      listing_price: item?.listing_price || item?.price || ""
    };
  }).filter(item => /^https?:\/\//i.test(item.url));
  return products.slice(0, Number.isFinite(LIMIT) ? LIMIT : undefined);
}

async function clickLabel(page, pattern) {
  const candidates = page.locator("button, a, [role='tab'], [role='button'], li, span");
  for (const locator of await candidates.all()) {
    const label = clean(await locator.innerText().catch(() => ""));
    if (!pattern.test(label) || label.length > 100 || !(await locator.isVisible().catch(() => false))) continue;
    if (await locator.evaluate(el => el.children.length > 2).catch(() => false)) continue;
    await locator.scrollIntoViewIfNeeded().catch(() => {});
    await locator.click({ timeout: 5000 }).catch(() => {});
    await page.waitForTimeout(WAIT_AFTER_ACTION_MS);
    return true;
  }
  return false;
}

async function extractTabContent(page, labelPattern) {
  return page.evaluate(patternSource => {
    const pattern = new RegExp(patternSource, "i");
    const norm = value => (value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
    const clickable = [...document.querySelectorAll("button,a,[role='tab'],[role='button'],li,span")]
      .find(element => norm(element.innerText) && pattern.test(norm(element.innerText)) && norm(element.innerText).length < 100);
    if (!clickable) return "";
    let node = clickable;
    for (let depth = 0; depth < 5 && node; depth++, node = node.parentElement) {
      const panel = node.querySelector("[role='tabpanel'], .tab-content, .content, [class*='tab-content']");
      if (panel && norm(panel.innerText)) return norm(panel.innerText);
    }
    const siblings = [clickable.parentElement?.nextElementSibling, clickable.parentElement?.parentElement?.nextElementSibling];
    return norm(siblings.find(element => norm(element?.innerText))?.innerText || "");
  }, labelPattern.source);
}

async function getProductData(page) {
  return page.evaluate(() => {
    const text = value => (value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
    const readJsonLd = () => {
      const products = [];
      for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
        try {
          const walk = node => {
            if (!node) return;
            if (Array.isArray(node)) return node.forEach(walk);
            if (typeof node !== "object") return;
            const type = node["@type"];
            if (type === "Product" || (Array.isArray(type) && type.includes("Product"))) products.push(node);
            if (node["@graph"]) walk(node["@graph"]);
          };
          walk(JSON.parse(script.textContent || "null"));
        } catch {}
      }
      return products[0] || {};
    };
    const jsonProduct = readJsonLd();
    const offer = Array.isArray(jsonProduct.offers) ? jsonProduct.offers[0] : jsonProduct.offers || {};
    const title = text(document.querySelector("h1.page-title, h1 .base, h1")?.innerText || jsonProduct.name);
    const description = text(document.querySelector(".product.attribute.overview, .product-info-main .overview, [itemprop='description'], .product-description")?.innerText || jsonProduct.description);
    const priceNode = document.querySelector(".product-info-main .price, .price-box .price, [data-price-type='finalPrice'] .price, [itemprop='price']");
    const price = text(priceNode?.getAttribute("content") || priceNode?.getAttribute("data-price-amount") || priceNode?.innerText || offer.price);
    const images = [...document.querySelectorAll(".fotorama__stage img, .fotorama__nav img, .product-image-photo, .gallery-placeholder img, img[itemprop='image']")]
      .map(image => image.getAttribute("data-src") || image.getAttribute("data-original") || image.getAttribute("src") || image.currentSrc || "");
    const jsonImages = Array.isArray(jsonProduct.image) ? jsonProduct.image : [jsonProduct.image];
    return { title, description, price, image_urls: [...new Set([...images, ...jsonImages].filter(Boolean))] };
  });
}

async function extractFullIngredients(page) {
  await clickLabel(page, /view full ingredient list/i);
  await page.waitForTimeout(WAIT_AFTER_ACTION_MS);
  return page.evaluate(() => {
    const norm = value => (value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
    const headings = [...document.querySelectorAll("h1,h2,h3,h4,h5,strong,button,a")];
    const heading = headings.find(element => /^ingredients?$/i.test(norm(element.innerText)));
    if (heading) {
      let node = heading;
      for (let depth = 0; depth < 5 && node; depth++, node = node.parentElement) {
        const content = norm(node.innerText);
        if (content.length > norm(heading.innerText).length + 20 && content.length < 12000) {
          return content.replace(/^ingredients?\s*/i, "").trim();
        }
      }
    }
    const dialog = document.querySelector('[role="dialog"], .modal-content, .fancybox-content');
    if (dialog && norm(dialog.innerText)) return norm(dialog.innerText);
    return "";
  });
}

async function scrapeProduct(page, product) {
  await page.goto(product.url, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.waitForSelector("h1, .product-info-main", { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(400);
  const base = await getProductData(page);

  await clickLabel(page, /^what is it\??$/i);
  const what_is_it = await extractTabContent(page, /^what is it\??$/i);
  await clickLabel(page, /^what does it do\??$/i);
  const what_does_it_do = await extractTabContent(page, /^what does it do\??$/i);
  const full_ingredient_list = await extractFullIngredients(page);

  const image_urls = unique([product.listing_image_url, ...base.image_urls]);
  return {
    title: base.title || product.title || "",
    url: product.url,
    price: base.price || product.listing_price || "",
    description: base.description,
    what_is_it,
    what_does_it_do,
    full_ingredient_list,
    image_url: image_urls[0] || "",
    image_urls,
    listing_price: product.listing_price || "",
    scrape_status: "success"
  };
}

async function saveResults(rows, products) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  fs.writeFileSync(path.join(OUTPUT_DIR, "forest-essentials-products.json"), JSON.stringify(rows, null, 2), "utf8");
  fs.writeFileSync(path.join(OUTPUT_DIR, "forest-essentials-products.jsonl"), rows.map(row => JSON.stringify(row)).join("\n") + (rows.length ? "\n" : ""), "utf8");
  fs.writeFileSync(path.join(OUTPUT_DIR, "forest-essentials-urls.json"), JSON.stringify(products, null, 2), "utf8");

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Forest Essentials");
  const columns = ["title", "price", "description", "what_is_it", "what_does_it_do", "full_ingredient_list", "image_url", "image_urls", "url", "listing_price", "scrape_status", "scrape_error"];
  sheet.columns = columns.map(key => ({ header: key, key, width: ["description", "what_is_it", "what_does_it_do", "full_ingredient_list"].includes(key) ? 55 : 28 }));
  for (const row of rows) sheet.addRow({ ...row, image_urls: (row.image_urls || []).join("\n") });
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  await workbook.xlsx.writeFile(path.join(OUTPUT_DIR, "forest-essentials-products.xlsx"));
}

async function main() {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const products = readProductUrls();
  if (!products.length) throw new Error(`No product URLs found in ${INPUT_FILE}`);
  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const results = [];
  try {
    fs.writeFileSync(path.join(OUTPUT_DIR, "forest-essentials-urls.json"), JSON.stringify(products, null, 2), "utf8");
    console.log(`Read ${products.length} product URLs from ${INPUT_FILE}. Starting product detail scrape.`);

    for (let index = 0; index < products.length; index++) {
      const product = products[index];
      console.log(`[${index + 1}/${products.length}] ${product.title} — ${product.url}`);
      try {
        results.push(await scrapeProduct(page, product));
      } catch (error) {
        console.error(`Failed: ${product.url} — ${error.message}`);
        results.push({ title: product.title, url: product.url, image_urls: unique([product.listing_image_url]), scrape_status: "error", scrape_error: error.message });
      }
      await saveResults(results, products);
    }
    console.log(`Saved ${results.length} products in ${OUTPUT_DIR}`);
  } finally {
    await browser.close();
  }
}

main().catch(error => {
  console.error(error.message);
  process.exitCode = 1;
});
