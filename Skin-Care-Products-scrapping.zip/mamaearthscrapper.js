import fs from "node:fs";
import path from "node:path";
import * as cheerio from "cheerio";
import ExcelJS from "exceljs";

// ================= CONFIG =================
const INPUT_FILE = process.argv[2] || "mamaearth.json";
const OUT_DIR = "output";
const JSONL_FILE = path.join(OUT_DIR, "products.jsonl"); // appended after every product (source of truth)
const JSON_FILE = path.join(OUT_DIR, "products.json");   // full array, refreshed periodically
const XLSX_FILE = path.join(OUT_DIR, "products.xlsx");   // refreshed periodically
const BASE_URL = "https://mamaearth.in/products/";
const DELAY_MS = 600;     // pause between requests (be polite)
const SAVE_EVERY = 5;     // rewrite JSON array + Excel every N products
const MAX_RETRIES = 3;
// ==========================================

fs.mkdirSync(OUT_DIR, { recursive: true });
// ---------- 1. Read input: pull every product object out, whatever the file format ----------
function extractProducts(text) {
  const found = [];
  const stack = [];
  let inStr = false, esc = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') { inStr = true; continue; }

    if (ch === "{") {
      stack.push({ start: i, hasProduct: false });
    } else if (ch === "}") {
      const frame = stack.pop();
      if (!frame) continue;

      if (frame.hasProduct) {
        if (stack.length) stack[stack.length - 1].hasProduct = true;
        continue;
      }

      const slice = text.slice(frame.start, i + 1);
      if (slice.includes('"handle"') && slice.includes('"variants"')) {
        try {
          const obj = JSON.parse(slice);
          if (obj && obj.handle) {
            found.push(obj);
            if (stack.length) stack[stack.length - 1].hasProduct = true;
          }
        } catch {
          /* broken object, skip it */
        }
      }
    }
  }
  return found;
}

const raw = fs.readFileSync(INPUT_FILE, "utf8");
const byHandle = new Map();
for (const p of extractProducts(raw)) {
  if (p?.handle && !byHandle.has(p.handle)) byHandle.set(p.handle, p);
}
const products = [...byHandle.values()];
console.log(`Found ${products.length} unique products`);
// ---------- 2. Resume support: load what is already scraped ----------
const results = [];
const done = new Set();
if (fs.existsSync(JSONL_FILE)) {
  for (const line of fs.readFileSync(JSONL_FILE, "utf8").split("\n")) {
    if (!line.trim()) continue;
    try {
      const row = JSON.parse(line);
      results.push(row);
      done.add(row.handle);
    } catch {}
  }
  console.log(`Resuming: ${done.size} products already saved`);
}

// ---------- 3. Page scraper ----------
const clean = (s) => (s || "").replace(/\s+/g, " ").trim();

function extractPage(html) {
  const $ = cheerio.load(html);

  const pillList = $(".what-it-does-list").first();
  const skin_type = clean(pillList.find(".what-it-does-skin-type").text());
  const benefits = pillList
    .find(".what-it-does-pill").not(".what-it-does-skin-type")
    .map((_, el) => clean($(el).text())).get();

  const priceBlock = $(".hdt-price__sale").first();
  const price = {
    sale_price: clean(priceBlock.find("hdt-price .hdt-money").first().text()),
    mrp: clean(priceBlock.find("hdt-compare-at-price .hdt-money").first().text()),
    discount: clean(priceBlock.find(".discount-percentage").first().text()),
  };

  const sections = {};
  $(".hdt-product-accordion__item").each((_, el) => {
    const $el = $(el);
    const title = clean($el.find("summary .hdt-product-accordion__text").text());
    if (!title) return;
    const content = $el.find(".hdt-product-accordion__content, .product-faqs-content").first();

    if (title === "Product description") {
      sections[title] = clean(content.text());
    } else if (title === "Key Ingredients") {
      sections[title] = content.find(".product-detail-card-inner").map((_, c) => ({
        name: clean($(c).find(".product-detail-card-title").text()).replace(/\s*:\s*$/, ""),
        benefit: clean($(c).find(".detail1").text()),
      })).get();
    } else if (title === "Ingredients List") {
      sections[title] = clean(content.find(".product-detail-card-description").text());
    } else if (title === "FAQ") {
      sections[title] = $el.find(".product-faqs-item").map((_, f) => ({
        question: clean($(f).find("strong").text()),
        answer: clean($(f).find("p").text()),
      })).get();
    } else {
      sections[title] = content.find(".detail1").map((_, d) => clean($(d).text())).get();
    }
  });

  const rr = $("#judgeme_product_reviews");
  const customer_reviews = {
    average_rating: rr.find(".jdgm-rev-widg").attr("data-average-rating") || null,
    total_reviews: rr.find(".jdgm-rev-widg").attr("data-number-of-reviews") || null,
    items: rr.find(".jdgm-rev").map((_, r) => ({
      author: clean($(r).find(".jdgm-rev__author").text()),
      rating: Number($(r).find(".jdgm-rev__rating").attr("data-score")) || null,
      date: $(r).find(".jdgm-rev__timestamp").attr("datetime") || null,
      review: clean($(r).find(".jdgm-rev__body").text()),
    })).get(),
  };

  return {
    page_title: clean($("h1.hdt-product__title").first().text()),
    skin_type, benefits, price, sections, customer_reviews,
  };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function fetchHtml(url) {
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
      if (res.status === 404) throw Object.assign(new Error("HTTP 404"), { noRetry: true });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.text();
    } catch (e) {
      if (e.noRetry || attempt === MAX_RETRIES) throw e;
      await sleep(1500 * attempt);
    }
  }
}

// ---------- 4. Excel + JSON writers ----------
const cell = (v) => {
  const s = typeof v === "string" ? v : JSON.stringify(v ?? "");
  return s.length > 32000 ? s.slice(0, 32000) : s; // Excel cell limit is 32,767
};

const COLUMNS = [
  { header: "Product ID", key: "id", width: 16 },
  { header: "Title", key: "title", width: 45 },
  { header: "Handle", key: "handle", width: 40 },
  { header: "URL", key: "url", width: 50 },
  { header: "Product Type", key: "product_type", width: 20 },
  { header: "Tags", key: "tags", width: 40 },
  { header: "Image URLs", key: "images", width: 60 },
  { header: "Skin Type", key: "skin_type", width: 18 },
  { header: "Benefits", key: "benefits", width: 30 },
  { header: "Sale Price", key: "sale_price", width: 12 },
  { header: "MRP", key: "mrp", width: 12 },
  { header: "Discount", key: "discount", width: 12 },
  { header: "Product Description", key: "description", width: 60 },
  { header: "Key Ingredients", key: "key_ingredients", width: 50 },
  { header: "How To Use", key: "how_to_use", width: 40 },
  { header: "Suitable For", key: "suitable_for", width: 30 },
  { header: "Ingredients List", key: "ingredients_list", width: 60 },
  { header: "FAQ", key: "faq", width: 60 },
  { header: "Avg Rating", key: "avg_rating", width: 10 },
  { header: "Review Count", key: "review_count", width: 12 },
  { header: "Reviews", key: "reviews", width: 60 },
  { header: "Status", key: "status", width: 20 },
];

function toExcelRow(r) {
  const s = r.sections || {};
  return {
    id: r.id,
    title: r.title,
    handle: r.handle,
    url: r.url,
    product_type: r.product_type,
    tags: (r.tags || []).join(", "),
    images: (r.images || []).join("\n"),
    skin_type: r.skin_type || "",
    benefits: (r.benefits || []).join(", "),
    sale_price: r.price?.sale_price || "",
    mrp: r.price?.mrp || "",
    discount: r.price?.discount || "",
    description: cell(s["Product description"] || ""),
    key_ingredients: cell((s["Key Ingredients"] || []).map((k) => `${k.name}: ${k.benefit}`).join("\n")),
    how_to_use: cell((s["How to use"] || []).join("\n")),
    suitable_for: cell((s["Suitable for"] || []).join("\n")),
    ingredients_list: cell(s["Ingredients List"] || ""),
    faq: cell((s["FAQ"] || []).map((f) => `Q: ${f.question}\nA: ${f.answer}`).join("\n\n")),
    avg_rating: r.customer_reviews?.average_rating || "",
    review_count: r.customer_reviews?.total_reviews || "",
    reviews: cell((r.customer_reviews?.items || []).map((i) => `${i.author} (${i.rating}): ${i.review}`).join("\n")),
    status: r.status,
  };
}

async function saveAll() {
  fs.writeFileSync(JSON_FILE, JSON.stringify(results, null, 2));
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("Products");
  ws.columns = COLUMNS;
  ws.getRow(1).font = { bold: true };
  ws.views = [{ state: "frozen", ySplit: 1 }];
  for (const r of results) {
    const row = ws.addRow(toExcelRow(r));
    row.alignment = { wrapText: true, vertical: "top" };
  }
  await wb.xlsx.writeFile(XLSX_FILE);
}

// Save cleanly on Ctrl+C
let stopping = false;
process.on("SIGINT", async () => {
  if (stopping) return;
  stopping = true;
  console.log("\nStopping... saving progress");
  await saveAll();
  process.exit(0);
});

// ---------- 5. Main loop (one by one) ----------
let sinceSave = 0;
for (let i = 0; i < products.length && !stopping; i++) {
  const p = products[i];
  if (done.has(p.handle)) continue;

  const url = BASE_URL + p.handle;
  // Data that comes from your JSON file
  const base = {
    id: p.id,
    title: p.title,
    handle: p.handle,
    url,
    product_type: p.product_type || "",
    tags: p.tags || [],
    images: (p.images || []).map((img) => img.src),
  };

  let row;
  try {
    const html = await fetchHtml(url);
    row = { ...base, ...extractPage(html), status: "ok" };
  } catch (e) {
    row = { ...base, status: `error: ${e.message}` };
  }

  results.push(row);
  done.add(p.handle);
  fs.appendFileSync(JSONL_FILE, JSON.stringify(row) + "\n"); // saved immediately, one by one
  console.log(`[${done.size}/${products.length}] ${row.status.padEnd(10)} ${p.handle}`);

  if (++sinceSave >= SAVE_EVERY) {
    await saveAll();
    sinceSave = 0;
  }
  await sleep(DELAY_MS);
}

await saveAll();
console.log(`Done. Files in ./${OUT_DIR}: products.jsonl, products.json, products.xlsx`);