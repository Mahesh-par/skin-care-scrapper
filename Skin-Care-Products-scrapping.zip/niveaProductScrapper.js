import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ExcelJS from "exceljs";
import { chromium } from "playwright";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const inputArg = process.argv.indexOf("--input");
const INPUT_FILE = path.resolve(__dirname, inputArg >= 0 ? process.argv[inputArg + 1] : "niviea.json");
const OUTPUT_DIR = path.resolve(__dirname, "niviea reesult");
const LIMIT_ARG = process.argv.indexOf("--limit");
const LIMIT = LIMIT_ARG >= 0 ? Number(process.argv[LIMIT_ARG + 1]) : Infinity;
const SECTIONS = [
  ["benefits", /^(benefits|key benefits)$/i],
  ["how_to_apply", /^(how to apply|how to use|application)$/i],
  ["ingredients", /^ingredients?$/i],
  ["more_information", /^more information$/i]
];

const clean = value => String(value ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function readInput() {
  if (!fs.existsSync(INPUT_FILE)) throw new Error(`Input file not found: ${INPUT_FILE}`);
  const parsed = JSON.parse(fs.readFileSync(INPUT_FILE, "utf8"));
  const products = Array.isArray(parsed) ? parsed : parsed.products;
  if (!Array.isArray(products)) throw new Error("Input JSON must be an array or contain a products array.");
  return products.filter(product => product?.url).slice(0, Number.isFinite(LIMIT) ? LIMIT : undefined);
}

async function openAccordion(page, labelRegex) {
  const items = page.locator("[data-accordion-value], [data-slot='accordion-item']");
  for (const item of await items.all()) {
    const heading = item.locator("h1,h2,h3,h4,h5,h6,[data-slot='accordion-trigger'],button,[role='button']").first();
    if (!(await heading.count())) continue;
    const label = clean(await heading.innerText().catch(() => ""));
    if (!labelRegex.test(label)) continue;

    const itemState = await item.getAttribute("data-state").catch(() => null);
    const headingState = await heading.getAttribute("data-state").catch(() => null);
    if (itemState !== "open" && headingState !== "open") {
      await heading.scrollIntoViewIfNeeded().catch(() => {});
      await heading.click({ timeout: 5000 }).catch(async () => {
        await item.locator("button,[role='button']").first().click({ timeout: 3000 }).catch(() => {});
      });
      await sleep(250);
    }

    const content = item.locator("[data-slot='accordion-content'], [data-slot='accordion-content'] > *, [class*='accordion-content']").last();
    const text = clean(await content.innerText().catch(() => ""));
    if (text) return text;
    return clean(await item.innerText().catch(() => "")).replace(label, "").trim();
  }
  return "";
}

async function getProductPageData(page) {
  return page.evaluate(() => {
    const text = value => (value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
    const meta = selector => document.querySelector(selector)?.content || "";
    const parseJsonLd = () => {
      const found = [];
      for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
        try {
          const value = JSON.parse(script.textContent || "null");
          const visit = node => {
            if (!node) return;
            if (Array.isArray(node)) return node.forEach(visit);
            if (typeof node !== "object") return;
            const type = node["@type"];
            if (type === "Product" || (Array.isArray(type) && type.includes("Product"))) found.push(node);
            if (node["@graph"]) visit(node["@graph"]);
          };
          visit(value);
        } catch {}
      }
      return found[0] || {};
    };
    const product = parseJsonLd();
    const offers = Array.isArray(product.offers) ? product.offers[0] : product.offers || {};
    const title = text(document.querySelector("h1.product-name, h1")?.innerText || product.name);
    const description = text(
      document.querySelector(".short-desc, .description-text, [class*='short-desc']")?.innerText ||
      meta('meta[name="description"]') || product.description
    );
    const priceNode = document.querySelector('[itemprop="price"], [class*="price"] [class*="value"], [class*="product-price"], .price');
    const price = text(priceNode?.getAttribute("content") || priceNode?.innerText || offers.price || "");
    const ratingNode = document.querySelector('[itemprop="ratingValue"], [class*="rating"] [aria-label], [class*="rating"]');
    const rating = text(ratingNode?.getAttribute("content") || ratingNode?.getAttribute("aria-label") || ratingNode?.innerText || "");

    const propertyValue = label => {
      const rows = [...document.querySelectorAll(".attributes > *, [class*='attribute'], [class*='product-attribute']")];
      const matchingRows = rows
        .map(element => ({ element, content: text(element.innerText) }))
        .filter(({ content }) => new RegExp(`^${label}(?:\\s|$)`, "i").test(content));
      const row = matchingRows.sort((a, b) => a.content.length - b.content.length)[0];
      return text(row?.content).replace(new RegExp(`^${label}\\s*`, "i"), "");
    };
    const details = {};
    for (const label of ["Size", "Attribute", "Skin Concern", "Skin Type", "Care Category"]) {
      const value = propertyValue(label);
      if (value && value.toLowerCase() !== label.toLowerCase()) details[label.toLowerCase().replaceAll(" ", "_")] = value;
    }
    return {
      title,
      price,
      description,
      rating,
      size: details.size || "",
      attribute: details.attribute || "",
      skin_concern: details.skin_concern || "",
      skin_type: details.skin_type || "",
      care_category: details.care_category || "",
      image_url: product.image || ""
    };
  });
}

async function scrapeProduct(page, source) {
  await page.goto(source.url, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.locator("h1").first().waitFor({ state: "visible", timeout: 30000 }).catch(() => {});
  await sleep(700);
  const details = await getProductPageData(page);
  const sections = {};
  for (const [key, label] of SECTIONS) sections[key] = await openAccordion(page, label);

  return {
    ...source,
    title: details.title || source.title || "",
    url: source.url,
    price: details.price,
    description: details.description,
    rating: details.rating || source.rating || "",
    size: details.size,
    attribute: details.attribute,
    skin_concern: details.skin_concern,
    skin_type: details.skin_type,
    care_category: details.care_category,
    image_url: details.image_url || source.image_url || "",
    benefits: sections.benefits,
    how_to_apply: sections.how_to_apply,
    ingredients: sections.ingredients,
    more_information: sections.more_information,
    scrape_status: "success"
  };
}

async function saveResults(rows) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  fs.writeFileSync(path.join(OUTPUT_DIR, "niviea-products.json"), JSON.stringify(rows, null, 2), "utf8");
  fs.writeFileSync(path.join(OUTPUT_DIR, "niviea-products.jsonl"), rows.map(row => JSON.stringify(row)).join("\n") + (rows.length ? "\n" : ""), "utf8");

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("NIVEA Products");
  const columns = ["title", "price", "description", "benefits", "how_to_apply", "ingredients", "more_information", "size", "attribute", "skin_concern", "skin_type", "care_category", "rating", "url", "image_url", "category", "listing_text", "scrape_status", "scrape_error"];
  sheet.columns = columns.map(key => ({ header: key, key, width: key === "description" || key === "ingredients" || key.includes("information") || key === "benefits" ? 50 : 24 }));
  for (const row of rows) sheet.addRow(Object.fromEntries(columns.map(key => [key, row[key] ?? ""])));
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  await workbook.xlsx.writeFile(path.join(OUTPUT_DIR, "niviea-products.xlsx"));
}

async function main() {
  const products = readInput();
  if (!products.length) throw new Error("No product URLs found in the input file.");
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const results = [];
  try {
    for (let index = 0; index < products.length; index++) {
      const source = products[index];
      console.log(`[${index + 1}/${products.length}] ${source.url}`);
      try {
        results.push(await scrapeProduct(page, source));
      } catch (error) {
        console.error(`Failed: ${source.url} — ${error.message}`);
        results.push({ ...source, scrape_status: "error", scrape_error: error.message });
      }
      await saveResults(results);
    }
  } finally {
    await browser.close();
  }
  console.log(`Saved ${results.length} products to: ${OUTPUT_DIR}`);
}

main().catch(error => {
  console.error(error.message);
  process.exitCode = 1;
});
