import fs from "node:fs";
import path from "node:path";
import ExcelJS from "exceljs";
import { chromium } from "playwright";

const BASE_URL = "https://nivea.in/products";
const OUTPUT_DIR = "nivea result";
const MAX_LOAD_MORE_CLICKS = 50;
const LOAD_WAIT_MS = 1500;

fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const clean = value => String(value ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();

async function collectProducts(page) {
  return page.locator('a[href*="/products/"]').evaluateAll(anchors => {
    const collected = new Map();

    for (const anchor of anchors) {
      const href = anchor.getAttribute("href") || "";
      if (!/\/products\/[^/?#]+/i.test(href)) continue;

      const url = new URL(href, location.origin).href;
      if (collected.has(url)) continue;

      const tracking = anchor.getAttribute("data-tracking-params");
      let trackingData = {};
      try { trackingData = JSON.parse(tracking || "{}"); } catch {}

      const text = value => (value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
      const title = text(
        anchor.querySelector("[class*='teaser_headline'], [class*='teaser-title'], [class*='teaser_title'], h2, h3, h4")?.innerText ||
        trackingData.teaser_title ||
        anchor.getAttribute("aria-label") ||
        anchor.querySelector("img")?.getAttribute("alt") ||
        anchor.innerText
      );
      const image = anchor.querySelector("img");
      const category = text(
        anchor.querySelector("[class*='teaser_category'], [class*='teaser-category'], [class*='product-category']")?.innerText
      );
      const ratingNode = anchor.querySelector("[aria-label*='star'], [aria-label*='rating'], [class*='rating']");

      collected.set(url, {
        title,
        url,
        category,
        image_url: image?.currentSrc || image?.src || "",
        rating: text(ratingNode?.getAttribute("aria-label") || ratingNode?.innerText),
        listing_text: text(anchor.innerText)
      });
    }

    return [...collected.values()];
  });
}

async function loadAllProducts(page) {
  let previousCount = 0;
  let unchangedClicks = 0;

  for (let clickNumber = 1; clickNumber <= MAX_LOAD_MORE_CLICKS; clickNumber++) {
    const products = await collectProducts(page);
    const count = products.length;
    console.log(`Loaded ${count} unique product links`);

    const button = page.locator("button").filter({ hasText: /load more|show more/i }).last();
    if (!(await button.count())) break;

    try {
      if (!(await button.isVisible()) || !(await button.isEnabled())) break;
      await button.scrollIntoViewIfNeeded();
      await button.click({ timeout: 10000 });
    } catch {
      break;
    }

    await page.waitForTimeout(LOAD_WAIT_MS);
    try {
      await page.waitForFunction(
        oldCount => document.querySelectorAll('a[href*="/products/"]').length > oldCount,
        count,
        { timeout: 12000 }
      );
    } catch {
      await page.waitForTimeout(1500);
    }

    const newCount = (await collectProducts(page)).length;
    if (newCount <= count || newCount <= previousCount) unchangedClicks++;
    else unchangedClicks = 0;
    if (unchangedClicks >= 2) break;

    previousCount = newCount;
    console.log(`Clicked Load more (${clickNumber}/${MAX_LOAD_MORE_CLICKS}); now ${newCount} products`);
  }

  return collectProducts(page);
}

async function saveExcel(products, filePath) {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("NIVEA Products");
  sheet.columns = [
    { header: "Product Name", key: "title", width: 50 },
    { header: "Category", key: "category", width: 25 },
    { header: "Product URL", key: "url", width: 70 },
    { header: "Image URL", key: "image_url", width: 70 },
    { header: "Rating", key: "rating", width: 25 },
    { header: "Listing Text", key: "listing_text", width: 60 }
  ];
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  for (const product of products) {
    sheet.addRow(product).alignment = { vertical: "top", wrapText: true };
  }
  await workbook.xlsx.writeFile(filePath);
}

async function main() {
  const browser = await chromium.launch({ headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    page.setDefaultTimeout(15000);
    await page.goto(BASE_URL, { waitUntil: "domcontentloaded", timeout: 60000 });
    await page.waitForTimeout(2000);

    const products = await loadAllProducts(page);
    const jsonPath = path.join(OUTPUT_DIR, "products.json");
    const jsonlPath = path.join(OUTPUT_DIR, "products.jsonl");
    const excelPath = path.join(OUTPUT_DIR, "products.xlsx");

    fs.writeFileSync(jsonPath, JSON.stringify(products, null, 2), "utf8");
    fs.writeFileSync(jsonlPath, products.map(product => JSON.stringify(product)).join("\n") + "\n", "utf8");
    await saveExcel(products, excelPath);

    console.log(`Finished: ${products.length} products saved to ${OUTPUT_DIR}`);
  } finally {
    await browser.close();
  }
}

main().catch(error => {
  console.error(`NIVEA scraper failed: ${error.message}`);
  process.exitCode = 1;
});
